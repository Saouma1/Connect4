let board = [];

for (let col = 0; col < 6; col++) {
    let newRow = []
    for (let row = 0; row < 7; row++) {
        newRow.push(0);
    }
    board.push(newRow);
}
console.log(board);

function set(row, col, player) {
    if (row < 7 && col < 6) {
        board[row][col] = player;
    }
}


function render() {
    const tab = document.querySelector('#mainTable');
    tab.innerHTML = '';

    const cre = document.createElement('table');
    for (let i = 0; i < 6; i++) {
        const tr = document.createElement('tr');
        for (let j = 0; j < 7; j++) {
            const td = document.createElement('td');

            td.dataset.column = j;

            td.textContent = board[i][j];
            tr.appendChild(td);

            if (board[i][j] === 1) {
                td.className = 'player1';
            }
            if (board[i][j] === 2) {
                td.className = 'player2';
            }
        }
        cre.appendChild(tr);
    }
    
    tab.appendChild(cre);
    cre.addEventListener('click', function(event) {
       if(event.target.tagName === 'TD'){
        play(event.target.dataset.column);
       }
    });
}
render();
let turn = 1;


function play(column) {
    for (let i = 5; i >= 0; i--) {
        if (board[i][column] === 0) {
            board[i][column] = turn;
            if (turn === 1) {
                turn = 2;
            }
            else {
                turn = 1;
            }
            render();
            return i;
        } 
    }
    return false;
}


